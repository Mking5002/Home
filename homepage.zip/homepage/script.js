document.getElementById('sidebar-toggle').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    const currentLeft = parseInt(window.getComputedStyle(sidebar).left);
    sidebar.style.left = currentLeft === 0 ? '-200px' : '0';
});

document.querySelector('.sidebar-close').addEventListener('click', function() {
    document.getElementById('sidebar').style.left = '-200px';
});

